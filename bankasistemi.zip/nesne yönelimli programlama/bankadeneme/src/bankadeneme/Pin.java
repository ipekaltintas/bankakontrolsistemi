package bankadeneme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.*;

public class Pin extends JFrame implements ActionListener{

	    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		JPasswordField t1, t2;
	    JButton b1, b2;
	    JLabel l1, l2, l3;
	    String pin;

	    public Pin(String pin) {
	        this.pin = pin;
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setBounds(100, 100, 450, 300);

	        JPanel contentPane = new JPanel();
	        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	        contentPane.setLayout(null);
	        setContentPane(contentPane);

	        l1 = new JLabel("ŞİFRENİ DEĞİŞTİR:");
	        l1.setFont(new Font("Tahoma", Font.BOLD, 14));
	        l1.setBounds(10, 10, 200, 30);
	        contentPane.add(l1);

	        l2 = new JLabel("YENİ ŞİFRE:");
	        l2.setFont(new Font("Tahoma", Font.BOLD, 12));
	        l2.setBounds(10, 60, 200, 30);
	        contentPane.add(l2);

	        l3 = new JLabel("YENİ ŞİFREYİ TEKRAR GİRİN:");
	        l3.setFont(new Font("Tahoma", Font.BOLD, 12));
	        l3.setBounds(10, 100, 200, 30);
	        contentPane.add(l3);

	        t1 = new JPasswordField();
	        t1.setBounds(220, 60, 150, 25);
	        contentPane.add(t1);

	        t2 = new JPasswordField();
	        t2.setBounds(220, 100, 150, 25);
	        contentPane.add(t2);

	        b1 = new JButton("DEĞİŞTİR");
	        b1.setBounds(220, 150, 100, 30);
	        b1.addActionListener(this);
	        contentPane.add(b1);

	        b2 = new JButton("GERİ");
	        b2.setBounds(100, 150, 100, 30);
	        b2.addActionListener(this);
	        contentPane.add(b2);

	        setVisible(true);
	    }

	    @Override
	    public void actionPerformed(ActionEvent e) {
	        try {
	            char[] npinArray = t1.getPassword();
	            char[] rpinArray = t2.getPassword();
	            String npin = new String(npinArray);
	            String rpin = new String(rpinArray);

	            if (!npin.equals(rpin)) {
	                JOptionPane.showMessageDialog(this, "Girdiğiniz şifreler uyuşmuyor!");
	                return;
	            }

	            if (e.getSource() == b1) {
	                if (npin.isEmpty() || rpin.isEmpty()) {
	                    JOptionPane.showMessageDialog(this, "Şifre alanlarını doldurun!");
	                    return;
	                }

	                Conn c1 = new Conn();
	                String q1 = "UPDATE banka SET pin = '" + rpin + "' WHERE pin = '" + pin + "'";
	                c1.s.executeUpdate(q1);

	                JOptionPane.showMessageDialog(this, "Şifre başarıyla değiştirildi.");
	                setVisible(false);
	                new islemler(rpin).setVisible(true);
	            } else if (e.getSource() == b2) {
	                setVisible(false);
	                new islemler(pin).setVisible(true);
	            }
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	    }

	    public static void main(String[] args) {
	        new Pin("").setVisible(true);
	    }
	}
