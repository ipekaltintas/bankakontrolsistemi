package bankadeneme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.sql.*;
import java.util.Date;

public class Fastcash extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private String pin;
    private JButton[] miktarButtons;
    private JButton backButton;

    // Hızlı para çekme seçenekleri (pozitif değerler, işlem sırasında negatif yapılacak)
    private final String[] miktar = {"100", "500", "1000", "2000", "5000", "10000"};

    public Fastcash(String pin) {
        this.pin = pin;

        // Frame ayarları
        setTitle("Hızlı Para Çekme");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 100, 600, 400);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Başlık
        JLabel titleLabel = new JLabel("ÇEKİLECEK MİKTARI SEÇİNİZ:");
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        titleLabel.setBounds(150, 20, 300, 30);
        contentPane.add(titleLabel);

        // Hızlı para çekme butonları
        miktarButtons = new JButton[miktar.length];
        int x = 150, y = 80;
        for (int i = 0; i < miktar.length; i++) {
            miktarButtons[i] = new JButton(miktar[i] + " TL");
            miktarButtons[i].setFont(new Font("Tahoma", Font.BOLD, 14));
            miktarButtons[i].setBounds(x, y, 150, 40);
            miktarButtons[i].addActionListener(this);
            contentPane.add(miktarButtons[i]);

            // Butonların düzenli görünmesi için konum değişimi
            if (i % 2 == 1) {
                x = 150;
                y += 60;
            } else {
                x += 200;
            }
        }

        // GERİ butonu
        backButton = new JButton("GERİ");
        backButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        backButton.setBounds(225, y + 60, 150, 40);
        backButton.addActionListener(this);
        contentPane.add(backButton);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        Object source = ae.getSource();

        if (source == backButton) {
            // GERİ butonuna basıldığında islemler ekranına dön
            this.setVisible(false);
            new islemler(pin).setVisible(true);
            return;
        }

        // Tıklanan butonun miktarını al
        for (int i = 0; i < miktar.length; i++) {
            if (source == miktarButtons[i]) {
                withdrawAmount(miktar[i]);
                return;
            }
        }
    }

    // Miktar çekme işlemi
    private void withdrawAmount(String miktar) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection("jdbc:sqlite:C:/oopveritabani/bankakontrolsistemi.db");

            // Bakiye sorgulama - Veritabanından mevcut bakiye alınacak
            String query = "SELECT * FROM banka WHERE pin = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, pin);
            rs = stmt.executeQuery();

            BigDecimal balance = BigDecimal.ZERO; // Başlangıç bakiyesi

            while (rs.next()) {
                BigDecimal transactionAmount = new BigDecimal(rs.getString("Miktar"));
                String transactionType = rs.getString("tip");

                // Bakiye hesaplama
                if (transactionType.equals("Para Yatır")) {
                    balance = balance.add(transactionAmount); // Para yatırıldığında bakiye artar
                } else if (transactionType.equals("Çekim") || transactionType.equals("Para Çek")) {
                    balance = balance.subtract(transactionAmount); // Para çekildiğinde bakiye azalır
                }
            }

            // Çekilmek istenen tutarı pozitif alıyoruz
            BigDecimal withdrawAmount = new BigDecimal(miktar); 

            // Bakiye kontrolü
            if (balance.compareTo(withdrawAmount) < 0) {
                JOptionPane.showMessageDialog(this, "Yetersiz Bakiye");
                return;
            }

            // Çekim işlemini veritabanına kaydetme
            Date tarih = new Date();
            String insertQuery = "INSERT INTO banka (pin, tarih, tip, miktar) VALUES (?, ?, ?, ?)";
            stmt = conn.prepareStatement(insertQuery);
            stmt.setString(1, pin);
            stmt.setString(2, tarih.toString());
            stmt.setString(3, "Çekim");  // Çekim tipi
            stmt.setString(4, "-" + miktar);  // Çekilen miktar negatif olarak ekleniyor
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, miktar + " TL işleminiz başarıyla gerçekleştirildi!");

            // İşlem sonrası tekrar işlemler ekranına dön
            this.setVisible(false);
            new islemler(pin).setVisible(true);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "SQL Hatası: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new Fastcash("1234").setVisible(true); // Test için örnek pin
    }
}
