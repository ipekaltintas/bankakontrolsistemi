package bankadeneme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.event.*;
import java.sql.*;

public class hesapekstiresi extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    JPanel contentPane;
    JButton b1;
    JLabel l1, l2, l3, l4;

    public hesapekstiresi(String pin) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        l1 = new JLabel();
        l1.setBounds(20, 140, 400, 200);
        contentPane.add(l1);

        l2 = new JLabel("Turkish Bank");
        l2.setBounds(150, 20, 100, 20);
        contentPane.add(l2);

        l3 = new JLabel();
        l3.setBounds(20, 80, 300, 20);
        contentPane.add(l3);

        l4 = new JLabel();
        l4.setBounds(20, 400, 300, 20);
        contentPane.add(l4);

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM girisyap WHERE pin = '" + pin + "'");
            while (rs.next()) {
                l3.setText("Kart Numarası: " + rs.getString("kartnumarası").substring(0, 4) + "XXXXXXXX" + rs.getString("kartnumarası").substring(12));
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Veritabanı hatası: " + e.getMessage());
        }

        try {
            int balance = 0;
            Conn c1 = new Conn();
            ResultSet rs = c1.s.executeQuery("SELECT * FROM banka WHERE pin = '" + pin + "'");
            while (rs.next()) {
                l1.setText(l1.getText() + "<html>" + rs.getString("tarih") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
                        rs.getString("tip") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
                        rs.getString("miktar") + "<br><br><html>");
                if (rs.getString("tip").equals("Para Yatır")) {
                    balance -= Integer.parseInt(rs.getString("miktar"));
                } else {
                    balance += Integer.parseInt(rs.getString("miktar"));
                }
            }
            l4.setText("BAKİYENİZ (TL): " + balance);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Veritabanı hatası: " + e.getMessage());
        }

        b1 = new JButton("ÇIKIŞ");
        b1.setBounds(20, 500, 100, 25);
        b1.addActionListener(this);
        contentPane.add(b1);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Çıkış butonuna basıldığında bu pencereyi captors
        this.setVisible(false);
    }

    public static void main(String[] args) {
        // Örnek pin ile başlatıyoruz
        new hesapekstiresi("1234").setVisible(true);
    }
}
