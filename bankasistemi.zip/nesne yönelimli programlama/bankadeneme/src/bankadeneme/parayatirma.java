package bankadeneme;

import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


import java.sql.*;

public class parayatirma extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private JTextField t1; // Kullanıcının yatırım miktarını gireceği alan
    private JButton b1, b2; // Yatırma ve Geri butonları
    private JLabel l1; // Etiket: Yatırılacak miktarı gösteren
    private String pin; // Kullanıcının PIN numarası
    private Conn c1;
	

    // Constructor
    public parayatirma(String pin) {
        this.pin = pin;

        // Frame ayarları
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 784, 579);
        
        JPanel contentPane = new JPanel();
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Etiket: Yatırılacak miktarı girin
        l1 = new JLabel("YATIRMAK İSTEDİĞİNİZ MİKTARI GİRİNİZ");
        l1.setBounds(150, 120, 300, 35);
        contentPane.add(l1);
        l1.setForeground(Color.BLACK);
        
        // Yatırım miktarı girecek alan
        t1 = new JTextField();
        t1.setBounds(150, 180, 200, 30);
        contentPane.add(t1);
        
        // Yatırma butonu
        b1 = new JButton("YATIR");
        b1.setBounds(150, 250, 150, 35);
        contentPane.add(b1);
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);

        // Geri butonu
        b2 = new JButton("GERİ");
        b2.setBounds(150, 300, 150, 35);
        contentPane.add(b2);
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);

        // Frame ayarları
        setSize(960, 1080);
        setUndecorated(true);
        setLocation(500, 0);
        setVisible(true);
    }

    // Butonlara tıklama işlemleri
    @Override
    public void actionPerformed(ActionEvent ae) {
        try {
            String miktar = t1.getText(); // Girilen miktar
            if (ae.getSource() == b1) {
                // Miktar boşsa kullanıcı uyarılır
                if (miktar.equals("")) {
                    JOptionPane.showMessageDialog(null, "Lütfen yatırmak istediğiniz miktarı girin");
                } else {
                    // Veritabanına yatırım işlemi eklenir
                    Conn c1 = new Conn();
                    String tarih = new java.util.Date().toString();
                    c1.s.executeUpdate("INSERT INTO banka (pin, tarih, tip, miktar) VALUES ('" + pin + "', '" + tarih + "', 'yatir', '" + miktar + "')");

                    // Yatırım sonrası bakiye güncellenir
                    updateBalanceAfterDeposit(miktar);

                    JOptionPane.showMessageDialog(null, miktar + " TL paranız başarıyla yatırılmıştır");

                    // Yatırım işleminden sonra islemler sayfasına dönülür
                    setVisible(false);
                    new islemler(pin).setVisible(true);
                }
            } else if (ae.getSource() == b2) {
                // Geri butonuna basıldığında islemler sayfasına dönülür
                setVisible(false);
                new islemler(pin).setVisible(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Bakiye güncelleme işlemi
    private void updateBalanceAfterDeposit(String miktar) {
        try {
            c1 = new Conn();
            // Mevcut bakiyeyi sorgulamak için
            String query = "SELECT * FROM banka WHERE pin = ?";
            PreparedStatement pstmt = Conn.connection.prepareStatement(query);
            pstmt.setString(1, pin);
            ResultSet rs = pstmt.executeQuery();
            
            int currentBalance = 0;
            while (rs.next()) {
                if (rs.getString("tip").equals("yatir")) {
                    currentBalance += Integer.parseInt(rs.getString("miktar"));
                } else if (rs.getString("tip").equals("cekme")) {
                    currentBalance -= Integer.parseInt(rs.getString("miktar"));
                }
            }

            // Yatırılan miktarı mevcut bakiyeye ekliyoruz
            int newBalance = currentBalance + Integer.parseInt(miktar);

            // Bakiye güncelleniyor
            String updateQuery = "UPDATE banka SET bakiye = ? WHERE pin = ?";
            PreparedStatement updateStmt = Conn.connection.prepareStatement(updateQuery);
            updateStmt.setInt(1, newBalance);
            updateStmt.setString(2, pin);
            updateStmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Main metodu (test için)
    public static void main(String[] args) {
        new parayatirma("1234").setVisible(true); // PIN numarasını test amaçlı sabit verdik
    }

	public Conn getC1() {
		return c1;
	}

	public void setC1(Conn c1) {
		this.c1 = c1;
	}
}
