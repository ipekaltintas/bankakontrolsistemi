package bankadeneme;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class giris extends JFrame implements ActionListener {
 
	private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField tfKartNo;
    private JPasswordField pfPin;
    private JButton b1, b2, b3;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                giris frame = new giris();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public giris() {
        // Pencere ayarları
        setTitle("ATM GİRİŞ EKRANI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 480);
        setLocation(550, 200);
        contentPane = new JPanel();
        contentPane.setLayout(null);
        contentPane.setBackground(Color.WHITE);
        setContentPane(contentPane);

        // Başlık
        JLabel l1 = new JLabel("ATM'E HOŞGELDİNİZ");
        l1.setFont(new Font("Tahoma", Font.BOLD, 18));
        l1.setBounds(280, 20, 300, 30);
        contentPane.add(l1);

        // Kart Numarası etiketi ve text field
        JLabel lKartNo = new JLabel("KART NO:");
        lKartNo.setFont(new Font("Tahoma", Font.BOLD, 12));
        lKartNo.setBounds(150, 100, 100, 20);
        contentPane.add(lKartNo);

        tfKartNo = new JTextField();
        tfKartNo.setBounds(250, 100, 200, 25);
        contentPane.add(tfKartNo);

        // PIN etiketi ve password field
        JLabel lPin = new JLabel("PIN:");
        lPin.setFont(new Font("Tahoma", Font.BOLD, 12));
        lPin.setBounds(150, 150, 100, 20);
        contentPane.add(lPin);

        pfPin = new JPasswordField();
        pfPin.setBounds(250, 150, 200, 25);
        contentPane.add(pfPin);

        // Giriş Yap butonu
        b1 = createButton("GİRİŞ YAP", 200, 220, 150, 30);
        b1.addActionListener(this);

        // Temizle butonu
        b2 = createButton("TEMİZLE", 380, 220, 150, 30);
        b2.addActionListener(this);

        // Kayıt Ol butonu
        b3 = createButton("KAYIT OL", 290, 280, 150, 30);
        b3.addActionListener(this);
    }

    private JButton createButton(String text, int x, int y, int width, int height) {
        JButton button = new JButton(text);
        button.setBounds(x, y, width, height);
        button.setFont(new Font("Tahoma", Font.BOLD, 14));
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        contentPane.add(button);
        return button;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
    	if (ae.getSource() == b1) { // Giriş Yap
            setVisible(false);
            islemler islemler1 = new islemler(null);
            islemler1.setVisible(true);
        
        } else if (ae.getSource() == b2) { // Temizle
            tfKartNo.setText("");
            pfPin.setText("");
        } else if (ae.getSource() == b3) { // Kayıt Ol
            setVisible(false);
            new kayitol().setVisible(true); // KayitOl sayfasını aç
        }
    }
}
