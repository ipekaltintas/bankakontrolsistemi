package bankadeneme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.math.BigDecimal;

public class bakiyesorgulama extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    JPanel contentPane;
    JButton b1, b2; // Butonlar: Bakiye sorgulama ve geri
    JLabel l1; // Bakiye etiket
    String pin; // Kullanıcının PIN numarası
    private Conn c1;

    // Constructor
    public bakiyesorgulama(String pin) {
        this.pin = pin;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 784, 579);

        contentPane = new JPanel();
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Bakiye sorgulama butonu
        b1 = new JButton("Güncel Bakiye");
        b1.setBounds(304, 37, 150, 35);
        contentPane.add(b1);
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);

        // Geri butonu
        b2 = new JButton("GERİ");
        b2.setBounds(304, 114, 150, 35);
        contentPane.add(b2);
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);

        // Bakiye göstermek için etiket
        l1 = new JLabel("GÜNCEL BAKİYENİZ: ");
        l1.setBounds(563, 41, 200, 25);
        contentPane.add(l1);
        l1.setForeground(Color.BLACK);

        setSize(960, 1080);
        setUndecorated(true);
        setLocation(500, 0);
        setVisible(true);
    }

    // Bakiye sorgulama (mevcut bakiye)
    private void updateBalance() {
        BigDecimal currentBalance = BigDecimal.ZERO;

        try {
            // Veritabanı bağlantısını sağlıyoruz
            setC1(new Conn());
            // Kullanıcının mevcut bakiyesini sorgulamak için SQL sorgusu
            String query = "SELECT * FROM banka WHERE bakiye = ?";
            PreparedStatement pstmt = Conn.connection.prepareStatement(query);
            pstmt.setString(1, pin);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                if (rs.getString("tip").equals("yatir")) {
                    currentBalance = currentBalance.add(new BigDecimal(rs.getString("miktar")));
                } else if (rs.getString("tip").equals("cekme") || rs.getString("tip").equals("para çek")) {
                    currentBalance = currentBalance.subtract(new BigDecimal(rs.getString("miktar")));
                }
            }

            // Güncel bakiyeyi ekrana yazdırıyoruz
            l1.setText("GÜNCEL BAKİYENİZ: " + currentBalance);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Veritabanı hatası: " + e.getMessage());
        }
    }

    // Butonlara tıklama işlemleri
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            // Bakiye sorgulama yapılır ve ekran güncellenir
            updateBalance(); // Güncel bakiye alınıyor
        } else if (e.getSource() == b2) {
            // Geri butonuna basıldığında islemler sayfasına dönülür
            setVisible(false);
            new islemler(pin).setVisible(true);
        }
    }

    public Conn getC1() {
        return c1;
    }

    public void setC1(Conn c1) {
        this.c1 = c1;
    }

    // Main metodu (test için)
    public static void main(String[] args) {
        new bakiyesorgulama("1234").setVisible(true); // PIN numarasını test amaçlı sabit verdik
    }
}
