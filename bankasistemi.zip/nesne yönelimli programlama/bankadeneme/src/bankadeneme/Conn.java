package bankadeneme;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.Statement;

import javax.swing.JOptionPane;
	public class Conn {
		    public static Connection connection;
		    Statement s;
		    Connection conn = null;
			public Conn() {
		        try {
		        	Class.forName("org.sqlite.JDBC");
		            connection = DriverManager.getConnection("jdbc:sqlite:C:/oopveritabani/bankakontrolsistemi.db");
		            s=connection.createStatement();
		            System.out.println("Bağlantı başarılı!");
		        } catch (Exception err) {
		            {
		    			JOptionPane.showMessageDialog(null, err);
		    			return ;
		    		}

		        }
		    }
	}

