package bankadeneme;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;

public class kayitol2 extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    JPanel contentPane;
    JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, l13;
    JButton b;
    JRadioButton r1, r2, r3, r4;
    JTextField t1, t2;
    JComboBox<String> c1, c2, c3, c4, c5;
    String formno;

    public kayitol2(String formno) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        this.formno = formno;
        setTitle("YENİ BAŞVURU FORMU-SAYFA 2");

        // Initialize labels
        l1 = new JLabel("Sayfa 2: Ek Bilgiler");
        l1.setFont(new Font("Raleway", Font.BOLD, 22));

        l2 = new JLabel("Din:");
        l3 = new JLabel("Kategori:");
        l4 = new JLabel("Gelir:");
        l5 = new JLabel("Eğitim:");
        l6 = new JLabel("Meslek:");
        l7 = new JLabel("PAN Numarası:");
        l8 = new JLabel("Aadhar Numarası:");
        l9 = new JLabel("İkinci Vatandaşlık:");
        l10 = new JLabel("Varolan Hesap:");
        l11 = new JLabel("Vasıf:");
        l12 = new JLabel("Form No:");
        l13 = new JLabel(formno);

        // Initialize button and radio buttons
        b = new JButton("İleri");
        b.setFont(new Font("Raleway", Font.BOLD, 14));
        b.setBackground(Color.BLACK);
        b.setForeground(Color.WHITE);

        t1 = new JTextField();
        t1.setFont(new Font("Raleway", Font.BOLD, 14));
        
        t2 = new JTextField();
        t2.setFont(new Font("Raleway", Font.BOLD, 14));

        r1 = new JRadioButton("Evet");
        r2 = new JRadioButton("Hayır");
        r3 = new JRadioButton("Evet");
        r4 = new JRadioButton("Hayır");

        // Initialize ComboBoxes
        String din[] = {"Hindu", "Muslim", "Sikh", "Christian", "Other"};
        c1 = new JComboBox<>(din);
        c1.setBackground(Color.WHITE);
        c1.setFont(new Font("Raleway", Font.BOLD, 14));

        String kategori[] = {"Genel", "OBC", "SC", "ST", "Diğer"};
        c2 = new JComboBox<>(kategori);
        c2.setBackground(Color.WHITE);
        c2.setFont(new Font("Raleway", Font.BOLD, 14));

        String gelir[] = {"Null", "<15000", "<25000", "<5000", "10000 üstü", "10000 altı"};
        c3 = new JComboBox<>(gelir);
        c3.setBackground(Color.WHITE);
        c3.setFont(new Font("Raleway", Font.BOLD, 14));

        String egitim[] = {"Mezun değil", "Mezun", "Lisansüstü", "Doktora", "Diğer"};
        c4 = new JComboBox<>(egitim);
        c4.setBackground(Color.WHITE);
        c4.setFont(new Font("Raleway", Font.BOLD, 14));

        String meslek[] = {"Maaşlı", "Kendi işi var", "Özel Sektör", "Öğrenci", "Emekli", "Diğer"};
        c5 = new JComboBox<>(meslek);
        c5.setBackground(Color.WHITE);
        c5.setFont(new Font("Raleway", Font.BOLD, 14));

        setLayout(null);

        // Add components to panel
        l12.setBounds(700, 10, 60, 30);
        add(l12);

        l13.setBounds(760, 10, 60, 30);
        add(l13);

        l1.setBounds(280, 30, 600, 40);
        add(l1);

        l2.setBounds(100, 120, 100, 30);
        add(l2);
        c1.setBounds(350, 120, 320, 30);
        add(c1);

        l3.setBounds(100, 170, 100, 30);
        add(l3);
        c2.setBounds(350, 170, 320, 30);
        add(c2);

        l4.setBounds(100, 220, 100, 30);
        add(l4);
        c3.setBounds(350, 220, 320, 30);
        add(c3);

        l5.setBounds(100, 270, 150, 30);
        add(l5);
        c4.setBounds(350, 270, 320, 30);
        add(c4);

        l6.setBounds(100, 340, 150, 30);
        add(l6);
        c5.setBounds(350, 340, 320, 30);
        add(c5);

        l7.setBounds(100, 390, 150, 30);
        add(l7);
        t1.setBounds(350, 390, 320, 30);
        add(t1);

        l8.setBounds(100, 440, 180, 30);
        add(l8);
        t2.setBounds(350, 440, 320, 30);
        add(t2);

        l9.setBounds(100, 490, 150, 30);
        add(l9);
        r1.setBounds(350, 490, 100, 30);
        add(r1);
        r2.setBounds(460, 490, 100, 30);
        add(r2);

        l10.setBounds(100, 540, 180, 30);
        add(l10);
        r3.setBounds(350, 540, 100, 30);
        add(r3);
        r4.setBounds(460, 540, 100, 30);
        add(r4);

        b.setBounds(570, 640, 100, 30);
        add(b);
        b.addActionListener(this);

        getContentPane().setBackground(Color.WHITE);

        setSize(850, 750);
        setLocation(500, 120);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String din = (String) c1.getSelectedItem();
        String kategori = (String) c2.getSelectedItem();
        String gelir = (String) c3.getSelectedItem();
        String egitim = (String) c4.getSelectedItem();
        String meslek = (String) c5.getSelectedItem();

        String pan = t1.getText();
        String aadhar = t2.getText();

        String ikincivatandaslik = "";
        if (r1.isSelected()) {
            ikincivatandaslik = "Evet";
        } else if (r2.isSelected()) {
            ikincivatandaslik = "Hayır";
        }

        String ehesap = "";
        if (r3.isSelected()) {
            ehesap = "Evet";
        } else if (r4.isSelected()) {
            ehesap = "Hayır";
        }

        try {
            if (pan.equals("") || aadhar.equals("")) {
                JOptionPane.showMessageDialog(null, "Boş geçilemeyen tüm boşlukları doldurun");
            } else {
                Conn c1 = new Conn();
                // Veriyi kaydetme işlemi
                String q1 = "INSERT INTO kayitol2 (formno, din, kategori, gelir, egitim, meslek, pan, aadhar, ikincivatandaslik, ehesap) "
                        + "VALUES ('" + formno + "', '" + din + "', '" + kategori + "', '" + gelir + "', '" + egitim + "', '" + meslek + "', '"
                        + pan + "', '" + aadhar + "', '" + ikincivatandaslik + "', '" + ehesap + "')";
                c1.s.executeUpdate(q1);

                // Sonraki sayfaya geçiş
                new kayitol3(formno).setVisible(true);
                setVisible(false);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new kayitol2("12345").setVisible(true);
    }
}



