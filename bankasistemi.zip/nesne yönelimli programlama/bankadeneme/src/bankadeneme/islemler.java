package bankadeneme;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class islemler extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel l1;
    private JButton b1, b2, b3, b4, b5, b6, b7;
    private String pin;

    public islemler(String pin) {
        this.pin = pin;

        // Frame ayarları
        setTitle("İşlem Seçimi");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // İçerik paneli
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null); // Manuel yerleşim
        setContentPane(contentPane);

        // Başlık
        l1 = new JLabel("LÜTFEN İŞLEMİNİZİ SEÇİN:");
        l1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
        l1.setBounds(250, 30, 300, 30);
        contentPane.add(l1);

        // Butonlar
        b1 = createButton("PARA YATIR", 150, 100);
        b2 = createButton("NAKİT ÇEK", 450, 100);
        b3 = createButton("FAST CASH", 150, 200);
        b4 = createButton("HESAP EKSTRESİ", 450, 200);
        b5 = createButton("ŞİFRE DEĞİŞTİR", 150, 300);
        b6 = createButton("BAKİYE SORGULAMA", 450, 300);
        b7 = createButton("ÇIKIŞ", 300, 400);

        // ActionListener ekleme
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);

        setVisible(true);
    }

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setFont(new Font("Tahoma", Font.BOLD, 12));
        button.setBounds(x, y, 200, 40);
        contentPane.add(button);
        return button;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b1) {
            setVisible(false);
            new parayatirma(pin).setVisible(true);
        } else if (ae.getSource() == b2) {
            setVisible(false);
            new paracekme(pin).setVisible(true);
        } else if (ae.getSource() == b3) {
            setVisible(false);
            new Fastcash(pin).setVisible(true);
        } else if (ae.getSource() == b4) {
            new hesapekstiresi(pin).setVisible(true);
        } else if (ae.getSource() == b5) {
            setVisible(false);
            new Pin(pin).setVisible(true);
        } else if (ae.getSource() == b6) {
            setVisible(false);
            new bakiyesorgulama(pin).setVisible(true);
        } else if (ae.getSource() == b7) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new islemler("").setVisible(true);
    }
}
