package bankadeneme;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class paracekme extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    JPanel contentPane;
    JButton b1, b2; // Butonlar: Para çekme ve geri
    JLabel l1; // Para çekme miktarı girecek alan
    JTextField t1; // Kullanıcının para çekme miktarını gireceği alan
    String pin; // Kullanıcının PIN numarası
    private Conn c1;

    // Constructor
    public paracekme(String pin) {
        this.pin = pin;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 784, 579);
        
        contentPane = new JPanel();
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Para çekme miktarı girecek etiket
        l1 = new JLabel("ÇEKMEK İSTEDİĞİNİZ MİKTARI GİRİNİZ");
        l1.setBounds(150, 120, 300, 35);
        contentPane.add(l1);
        l1.setForeground(Color.BLACK);
        
        // Para çekme miktarını girecek alan
        t1 = new JTextField();
        t1.setBounds(150, 180, 200, 30);
        contentPane.add(t1);
        
        // Para çekme butonu
        b1 = new JButton("ÇEK");
        b1.setBounds(150, 250, 150, 35);
        contentPane.add(b1);
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);

        // Geri butonu
        b2 = new JButton("GERİ");
        b2.setBounds(150, 300, 150, 35);
        contentPane.add(b2);
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);

        // Frame ayarları
        setSize(960, 1080);
        setUndecorated(true);
        setLocation(500, 0);
        setVisible(true);
    }

    // Butonlara tıklama işlemleri
    @Override
    public void actionPerformed(ActionEvent ae) {
        try {
            String miktar = t1.getText(); // Girilen miktar
            if (ae.getSource() == b1) {
                // Miktar boşsa kullanıcı uyarılır
                if (miktar.equals("")) {
                    JOptionPane.showMessageDialog(null, "Lütfen çekmek istediğiniz miktarı girin");
                } else {
                    // Mevcut bakiyeyi kontrol et
                    int currentBalance = getCurrentBalance();
                    
                    // Yeterli bakiye varsa işlem yapılır
                    if (currentBalance >= Integer.parseInt(miktar)) {
                        // Veritabanına çekim işlemi eklenir
                        Conn c1 = new Conn();
                        String tarih = new java.util.Date().toString();
                        c1.s.executeUpdate("INSERT INTO banka (pin, tarih, tip, miktar) VALUES ('" + pin + "', '" + tarih + "', 'cekme', '" + miktar + "')");

                        // Para çekildikten sonra bakiye güncellenir
                        updateBalanceAfterWithdrawal(miktar);

                        JOptionPane.showMessageDialog(null, miktar + " TL paranız başarıyla çekilmiştir");

                        // Para çekme işleminden sonra islemler sayfasına dönülür
                        setVisible(false);
                        new islemler(pin).setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Yeterli bakiye bulunmamaktadır");
                    }
                }
            } else if (ae.getSource() == b2) {
                // Geri butonuna basıldığında islemler sayfasına dönülür
                setVisible(false);
                new islemler(pin).setVisible(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Mevcut bakiyeyi sorgulama
    private int getCurrentBalance() {
        int currentBalance = 0;
        try {
            setC1(new Conn());
            String query = "SELECT * FROM banka WHERE pin = ?";
            PreparedStatement pstmt = Conn.connection.prepareStatement(query);
            pstmt.setString(1, pin);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                if (rs.getString("tip").equals("yatir")) {
                    currentBalance += Integer.parseInt(rs.getString("miktar"));
                } else if (rs.getString("tip").equals("cekme")) {
                    currentBalance -= Integer.parseInt(rs.getString("miktar"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return currentBalance;
    }

    // Bakiye güncelleniyor (para çekme işlemi sonrası)
    private void updateBalanceAfterWithdrawal(String miktar) {
        try {
            setC1(new Conn());
            int newBalance = getCurrentBalance() - Integer.parseInt(miktar);

            // Bakiye güncelleniyor
            String updateQuery = "UPDATE girisyap SET bakiye = ? WHERE pin = ?";
            PreparedStatement updateStmt = Conn.connection.prepareStatement(updateQuery);
            updateStmt.setInt(1, newBalance);
            updateStmt.setString(2, pin);
            updateStmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Main metodu (test için)
    public static void main(String[] args) {
        new paracekme("1234").setVisible(true); // PIN numarasını test amaçlı sabit verdik
    }

	public Conn getC1() {
		return c1;
	}

	public void setC1(Conn c1) {
		this.c1 = c1;
	}
}
